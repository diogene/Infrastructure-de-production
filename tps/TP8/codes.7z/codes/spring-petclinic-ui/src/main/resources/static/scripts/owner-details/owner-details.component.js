'use strict';

angular.module('ownerDetails')
    .component('ownerDetails', {
        templateUrl: 'scripts/owner-details/owner-details.template.html',
        controller: 'OwnerDetailsController'
    });
