================================================================================
===        Spring PetClinic sample application - Database Configuration      ===
================================================================================

@author Costin Leau

--------------------------------------------------------------------------------

In its default configuration, Petclinic uses an in-memory database (HSQLDB) which
gets populated at startup with data. A similar setup is provided for Mysql in case
a persistent database configuration is needed.
Note that whenever the database type is changed, the data-access.properties file needs to
be updated.




Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vel varius orci, nec sagittis nisl. Praesent congue diam mauris, sed euismod nunc cursus in. Pellentesque lorem metus, maximus ac venenatis nec, cursus in ligula. Proin vel leo mi. Mauris in fringilla nulla. Sed et laoreet nisi, non tempus leo. Maecenas sit amet facilisis enim. Vivamus bibendum cursus felis tincidunt congue.

In hac habitasse platea dictumst. Aliquam in volutpat lectus, sed elementum diam. Nunc tempus sapien in eros semper, sit amet egestas lectus fringilla. Donec sit amet malesuada velit. Sed ultrices felis quis ultrices lobortis. Nullam sagittis dui et metus semper convallis. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at libero eget lorem posuere lobortis. Vivamus tempor lectus in velit suscipit, ut fermentum nunc consectetur.

Nulla maximus tincidunt felis aliquam egestas. Aenean rutrum lorem ante, sodales pulvinar turpis eleifend eu. Integer accumsan turpis eget quam blandit fermentum. Curabitur aliquet molestie laoreet. Cras ultricies eget erat sagittis varius. Suspendisse semper orci tellus, et tincidunt enim ornare maximus. Vivamus at ullamcorper justo, eget convallis sem. Praesent dapibus vitae tellus posuere tristique. Sed vel laoreet arcu, eget iaculis velit. Fusce scelerisque sapien mauris, at maximus justo condimentum eget. Nulla lacinia tortor eu tincidunt suscipit. Fusce lectus tortor, semper non bibendum quis, elementum id diam. Nulla tristique mi tellus, sit amet convallis tortor viverra vitae. Nam tincidunt orci mattis eros mollis porta. Integer non enim orci.

Aenean mollis vestibulum tellus, a dictum nibh iaculis sit amet. Integer aliquam pellentesque magna, a bibendum leo fringilla quis. Ut sagittis sed sapien aliquam tincidunt. Curabitur quis ornare nulla. Duis aliquet, lectus ut faucibus lobortis, leo felis dapibus nunc, quis pharetra libero ipsum in arcu. Duis tempus aliquet elit, vitae ultricies lorem imperdiet cursus. Ut fermentum, lacus in finibus luctus, est turpis placerat metus, at ultrices lacus nisl non felis. Suspendisse porta odio nulla, eu euismod quam eleifend eu. Etiam aliquet mauris sed volutpat tincidunt. Vivamus sit amet tempus neque. Nullam finibus mauris sit amet lorem semper mollis. Vestibulum viverra sit amet elit ac egestas. Maecenas mollis nec nisl id tempor.

Nam pulvinar euismod lacinia. Maecenas iaculis consectetur nulla lobortis venenatis. Etiam diam odio, facilisis sed lorem ut, laoreet pellentesque augue. Morbi mattis metus magna, sit amet finibus nisl mattis sed. Nam in egestas sapien, et blandit nibh. Sed hendrerit elit odio, non lobortis odio gravida vel. Quisque a efficitur erat. Ut vel nulla congue, tincidunt ex ac, luctus dui. Donec eu sodales diam.

Aenean nec lectus ut felis fermentum hendrerit sed a eros. Donec non fermentum metus, sed consequat justo. Suspendisse eu sollicitudin justo, at dapibus ante. Nullam ut sapien orci. Cras congue tristique diam, non interdum sem fringilla quis. Pellentesque ornare enim ac dignissim pellentesque. Donec porta, enim ut feugiat ultrices, orci massa tristique urna, in dignissim lectus ligula eget ligula. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sed lorem metus. Donec tempus egestas sapien, sed maximus mauris posuere ut. Suspendisse potenti. Phasellus sit amet purus eu odio viverra vulputate. Donec eget enim id arcu dictum molestie et in ante. Aliquam quis felis dignissim, pretium metus porta, placerat urna. Ut non nisi orci.

Nullam ut pretium dolor, non dignissim ligula. Vestibulum ut felis non nulla placerat viverra. Integer non euismod mauris. Etiam nisl risus, porta ut consectetur non, elementum vel est. Proin mollis, ex et pretium ornare, erat orci tempus libero, in pellentesque eros eros et elit. Nam feugiat ante vel porta rhoncus. Morbi quis laoreet massa. Morbi quam eros, pretium mattis eros vitae, consectetur dignissim ante. Nullam convallis metus diam, nec aliquam urna tincidunt in. Ut non placerat nunc. Nullam consequat vitae felis vel dignissim. Vivamus faucibus pretium neque, sit amet dignissim felis fermentum sit amet. Proin sodales ac odio et dapibus.

Vestibulum sed neque enim. Cras ultricies enim nunc, et venenatis nulla consectetur a. Nulla sit amet augue et arcu imperdiet molestie. Aenean diam turpis, consectetur a mauris a, fermentum mollis risus. Sed cursus scelerisque turpis a blandit. Proin lorem odio, cursus nec tortor eget, facilisis hendrerit purus. Suspendisse sagittis interdum turpis, a dignissim mauris eleifend at. Praesent at mattis nulla, eget dignissim neque. Phasellus tortor elit, tincidunt id pellentesque non, mattis id tortor. Nulla id tellus est. Nam rhoncus, eros eu facilisis accumsan, sapien arcu tempus odio, a aliquet dolor velit id est. In sapien nunc, mollis a leo vitae, malesuada pellentesque ante. Integer posuere malesuada turpis.